﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Flash.External
{
    public partial class FlashAdder : UserControl
    {
        public event FlashFunctionCallEventHandler U_FlashFuncCallBack;
        public new event MouseEventHandler Click;
        private ExternalInterfaceProxy _proxy;

        public FlashAdder()
        {
            InitializeComponent();
            U_Movie = "";
            Click = null;
            _proxy = null;
        }
        public AxShockwaveFlashObjects.AxShockwaveFlash U_AxFlash { get { return FlashMovie; } }

        public String U_Movie
        {
            get
            {
                return FlashMovie.Movie;
            }
            set
            {
                if (value != null && value.Length > 0)
                {
                    FlashMovie.Movie = value;
                    FlashMovie.CausesValidation = false;
                    _proxy = new ExternalInterfaceProxy(FlashMovie);
                    _proxy.ExternalInterfaceCall += new ExternalInterfaceCallEventHandler(_proxy_ExternalInterfaceCall);
                }
            }
        }
        public void addRightMenu(String menuText, String CallBackFuncName, Boolean sepBefore, Boolean makeNew)
        {
            //addRightMenu(menuText:String, funcName:String, sepBefore:Boolean=false, mekeNew:Boolean= false){
            _proxy.Call("addRightMenu", menuText, CallBackFuncName, sepBefore, makeNew);
        }

        public String U_MovieOnThisPath
        {
            get
            {
                return FlashMovie.Movie;
            }
            set
            {
                U_setMovieThisPath(value);
            }
        }
        public String U_setMovieThisPath(String path)
        {
            try
            {
                if (path == null) return null;
                if (!path[0].Equals('.')) path = "\\" + path;
                return this.U_Movie = System.IO.Directory.GetCurrentDirectory() + path;
            }
            catch (NullReferenceException e)
            {
                Console.WriteLine("그런 파일이 없습니다." + e.Message);
                return null;
            }
        }
        public object U_CallFlashFunc(String funcName, params Object[] args)
        {
            return _proxy.Call(funcName, args);
        }
        public void U_setValue(params Object[] args)
        {
            U_CallFlashFunc("setValue", args);
        }
        public Object U_getValue()
        {
            return U_CallFlashFunc("getValue");
        }


        object _proxy_ExternalInterfaceCall(object sender, ExternalInterfaceCallEventArgs e)
        {
            if (e.FunctionCall.FunctionName.ToLower().Equals("click"))
            {
                MouseButtons btn;
                
                try
                {
                    btn = MouseButtons.Left;
                    int numOfClicked = 1;
                    int x = 0;
                    int y = 0;
                    int delta = 0;
                    Object[] args = e.FunctionCall.Arguments;

                    if (args.Length > 0)
                    {
                        String mouseKey = ((String)args[0]).ToLower();
                        switch (mouseKey)
                        {
                            case "left":
                                btn = MouseButtons.Left;
                                break;
                            case "right":
                                btn = MouseButtons.Right;
                                break;
                            case "middle":
                                btn = MouseButtons.Middle;
                                break;
                            case "both":
                                btn = MouseButtons.Left | MouseButtons.Right;
                                break;
                            case "xbutton1":
                                btn = MouseButtons.XButton1;
                                break;
                            case "xbutton2":
                                btn = MouseButtons.XButton2;
                                break;
                            case "delta":
                                btn = MouseButtons.None;
                                break;
                            default:
                                btn = MouseButtons.Left;
                                break;
                        }
                    }
                    if (args.Length > 1) numOfClicked = (Int32)(double)args[1];
                    if (args.Length > 2) x = (int)(double)args[2];
                    if (args.Length > 3) y = (int)((double)args[3]);
                    if (args.Length > 4) delta = (Int32)((double)args[4]);


                    Console.Write(Click);
                    if (Click != null)
                    {

                        Click(this, new MouseEventArgs(btn, numOfClicked, x, y, delta));
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("exception occured!:" + ex.Message);
                }
            }
            if (U_FlashFuncCallBack != null) return U_FlashFuncCallBack(sender, e.FunctionCall);
            else return null;
        }

    }
    public delegate object FlashFunctionCallEventHandler(object sender, ExternalInterfaceCall e);
}
